def handler(event, context): return {'statusCode': 200, 'body': 'v1.0.0 validation test'}
